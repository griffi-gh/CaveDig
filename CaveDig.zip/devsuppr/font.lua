fonts={}

fonts.default=love.graphics.newFont(12)
fonts.menu=love.graphics.newFont("/fonts/Nunito/Nunito-Bold.ttf",40)
fonts.title=love.graphics.newFont("/fonts/RussoOne.ttf",75)
